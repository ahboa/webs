'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // 生产环境地址
  BASE_API: '"http://production.com"'
}