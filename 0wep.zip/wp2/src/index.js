function hello(str){
    alert(str)
}